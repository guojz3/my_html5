<?php
// +----------------------------------------------------------------------
// | OneThink [ WE CAN DO IT JUST THINK IT ]
// +----------------------------------------------------------------------
// | Copyright (c) 2013 http://www.onethink.cn All rights reserved.
// +----------------------------------------------------------------------
// | Author: 麦当苗儿 <zuojiazi@vip.qq.com> <http://www.zjzit.cn>
// +----------------------------------------------------------------------

namespace Home\Controller;
use OT\DataDictionary;

/**
 * 前台首页控制器
 * 主要获取首页聚合数据
 */
class IndexController extends HomeController {

	//首页
    public function index(){

        $this->display();
    }

    public function login_index(){

        $this->display();
    }
    public function sandtu(){

        $this->display();
    }
    public function pingmiantu(){

        $this->display();
    }
    public function content(){
        $id = I('id');

        $m = M('Huzhu');
        $n = M('Chengyuan');
        $a = M('Zoufang');
        $p = M('Zoufang_pic');
        
        $where['id'] = $where_cy['hz_id'] = $id;

        $huzhu = $m->where($where)->find();
        $chengyuan = $n->where($where_cy)->select();
        $zf = $a->where($where_cy)->select();
        $list_p = $p->where($where_cy)->select();

        $this->assign('huzhu',$huzhu);
        $this->assign('cy',$chengyuan);
        $this->assign('zf',$zf);
        $this->assign('list_p',$list_p);
        $this->display();
    }
    public function xiangqingjianjie(){

        $this->display();
    }
    public function gongzuo(){

        $this->display();
    }
    public function images(){
        $id = I('id');
        
        $m = M('Zoufang_pic');
        
        $where['id'] = $id;
        
        $list = $m->where($where)->find();
        
        $this->assign('list',$list);
        $this->display();
    }
}